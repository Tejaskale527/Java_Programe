package ion;
import java.util.Scanner;
public class Reverse_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		sc.close();
		str = str.toLowerCase();
		StringBuffer strs = new StringBuffer(str);
		System.out.println(strs.reverse());

	}

}

// str = str.toLowerCase();
// StringBuffer strs = new StringBufeer(str);
//System.out.println(strs.reverse());