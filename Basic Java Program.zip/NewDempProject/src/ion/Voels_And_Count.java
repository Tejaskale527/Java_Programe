package ion;
import java.util.Scanner;
public class Voels_And_Count {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String string = sc.nextLine();
		sc.close();
		
		int vowel = 0;
		int count = 0;
		
		string = string.toLowerCase();
		for(int i = 0;i<string.length();i++)
		{
			
			if(string.charAt(i)=='a' ||string.charAt(i)=='e'||string.charAt(i)=='i'||string.charAt(i)=='o'
					||string.charAt(i)=='u')
			{
				vowel ++;
			}
			
			else if(string.charAt(i)>= 'a' && string.charAt(i)<= 'z')
			{
				count ++;
			}
		}
		System.out.println("The vowels are"+vowel);
		System.out.println("The count of vowel is"+count);
	}
	
}
