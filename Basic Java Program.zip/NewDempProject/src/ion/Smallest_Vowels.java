package ion;
import java.util.Scanner;
public class Smallest_Vowels {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);

		String str = sc.nextLine();
		sc.close();
		String [] vowels = {"a", "e", "i","o","u"};
		for(int i =0;i<vowels.length;i++)
		{
			if(str.contains(vowels[i]));
			{
				System.out.println(vowels[i]);
				break;
			}
		}
	}

}
