package ion;
import java.util.Scanner;
public class Swap_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		int a = 10;
		int b = 20;
		
		System.out.println("Enter the before number value of a" +a);
		System.out.println( "Enter the before number value of b" +b);
		a = a+b;
		b = a-b;
		a = a-b;
		
		System.out.println("Enter the aftere number value of a" +a);
		System.out.println("Enter the aftere number value of b"+b);

	}

}
