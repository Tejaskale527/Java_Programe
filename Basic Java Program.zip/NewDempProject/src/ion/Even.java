package ion;
import java.util.Scanner;
public class Even {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		sc.close();
		
		char[] result = str.toCharArray();
		for(int i=0;i<result.length;i = i+2)
		{
			System.out.print(result[i]);
		}

	}

}

//public getid() {
//	return id;
//}
//
//publiv void setid(int id)
//{
//	this.id = id;
//}