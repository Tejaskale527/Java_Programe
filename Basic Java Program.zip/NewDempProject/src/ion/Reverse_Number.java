package ion;
import java.util.Scanner;
public class Reverse_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		int input = sc.nextInt();
		sc.close();
		while(input != 0)
		{
			int d = input % 10;
			System.out.println(d);
			input = input / 10;
		}
		
	}

}
