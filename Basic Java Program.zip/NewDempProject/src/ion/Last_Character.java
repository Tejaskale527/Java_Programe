package ion;
import java.util.Scanner;

public class Last_Character {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner(System.in);
		String str = scan.nextLine();
		scan.close();
		char[] result = str.toCharArray();
		for(int i = 0; i <result.length;i++)
		{
            if(Character.isWhitespace(result[i]) && !Character.isDigit(result[i-1]) && !Character.isWhitespace(result[i-1])){
			
				System.out.println(result[i-1]);
			}
			
			else if(i==result.length-1 && !Character.isDigit(result[i]))
			{
				System.out.println(result[i]);
			}
			
		}
		

	}

}
