package ion;
import java.util.Scanner;
public class Odd {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        sc.close();
        
        char[] result = str.toCharArray();
        for(int i = 1; i<result.length; i=i+2)
        {
        	System.out.print(result[i]);
        }
	}

}
