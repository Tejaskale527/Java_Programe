package ion;
import java.util.Scanner;
public class Squre {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int number = sc.nextInt();
		sc.close();
		double result = Math.sqrt(number);
		if((int) result == result)
		{
			System.out.println("True");
		}
		else {
			System.out.println("False");
			
		}

	}

}
