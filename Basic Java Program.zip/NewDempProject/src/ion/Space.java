package ion;
import java.util.Scanner;
public class Space {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int count = 0;
		int space = 0;
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		sc.close();
		
		char[] result = str.toCharArray();
		for(int i = 0; i<result.length; i++)
		{
			if(!Character.isWhitespace(result[i]))
			{
				count++;
			}
			else if(!Character.isDigit(result[i]))
			{
				space++;
			}
		}
		
		System.out.println("The whiespace is" +count);
		System.out.println("Digit space is" +space);

	}

}
